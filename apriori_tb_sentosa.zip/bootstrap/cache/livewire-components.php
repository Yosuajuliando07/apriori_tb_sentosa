<?php return array (
  'aturan-asosiasi.hitung' => 'App\\Http\\Livewire\\AturanAsosiasi\\Hitung',
  'aturan-asosiasi.hitung-pola-tata-letak' => 'App\\Http\\Livewire\\AturanAsosiasi\\HitungPolaTataLetak',
  'aturan-asosiasi.rule-dua-item' => 'App\\Http\\Livewire\\AturanAsosiasi\\RuleDuaItem',
  'aturan-asosiasi.rule-tiga-item' => 'App\\Http\\Livewire\\AturanAsosiasi\\RuleTigaItem',
);