

<div class="pd-ltr-20 xs-pd-20-10">


    <div class="row pb-10">
        <div class="col-xl-6 col-lg-6 col-md-6 mb-20">
            <div class="card-box height-100-p widget-style3">
                <div class="d-flex flex-wrap">
                    <div class="widget-data">
                        <div class="weight-700 font-24 text-dark"><?php echo e($tglAwal); ?> - <?php echo e($tglAkhir); ?>

                        </div>
                        <div class="font-14 text-secondary weight-500">Range Tanggal Transaksi</div>
                    </div>
                    <div class="widget-icon">
                        <div class="icon" data-color="#00eccf" style="color: rgb(0, 236, 207);"><i
                                class="icon-copy dw dw-calendar1"></i></div>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
            <div class="card-box height-100-p widget-style3">
                <div class="d-flex flex-wrap">
                    <div class="widget-data">
                        <div class="weight-700 font-24 text-dark"><?php echo e($min_support); ?>%</div>
                        <div class="font-14 text-secondary weight-500">Minimum Support</div>
                    </div>
                    <div class="widget-icon">
                        <div class="icon"><i class="icon-copy fa fa-arrows-h" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-lg-3 col-md-6 mb-20">
            <div class="card-box height-100-p widget-style3">
                <div class="d-flex flex-wrap">
                    <div class="widget-data">
                        <div class="weight-700 font-24 text-dark"><?php echo e($min_confidence); ?>%</div>
                        <div class="font-14 text-secondary weight-500">Minimum Confidence</div>
                    </div>
                    <div class="widget-icon">
                        <div class="icon"><i class="icon-copy fa fa-arrows-h" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>

    </div>


    <div class="min-height-200px">
        <div class="pd-20 card-box mb-30">
            <div class="clearfix mb-20">
                <div class="pull-left">
                    <h4 class="text-blue h4">DATA TRANSAKSI</h4>
                </div>
                <div class="pull-right">
                    <a href="<?php echo e(route('tata-letak-barang.create')); ?>" class="btn btn-primary btn-sm"> Kembali</a>
                </div>
            </div>


            <div class="table-responsive">
                <table class="table table-bordered ">
                    <thead>
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col" class="w-25">Kode Transaksi</th>
                            <th scope="col">Jenis Bahan Bangunan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $data_transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($key); ?></td>
                                
                                <td><?php echo e(implode(', ', $data)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if(count($data_transaksi) >= 10 && count($data_transaksi) != $stopLoadTransaksi): ?>
                <button wire:click.prevent="loadDataTransaksi" class="btn btn-primary btn-sm btn-block">Tampilkan Lebih
                    Banyak
                </button>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="min-height-200px">
        <!-- Bordered table  start -->
        <div class="pd-20 card-box mb-30">
            <div class="clearfix mb-20">
                <div class="pull-left">
                    <h4 class="text-blue h4">C1 (Kandidat 1-itemset)</h4>
                    <small>
                        <p>Jika terdapat tabel berwarna <code>Merah</code> maka item tersebut kurang dari batasan
                            minimum
                            support <strong><?php echo e($min_support); ?>%</strong>
                        </p>
                    </small>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No </th>
                        <th scope="col">Item</th>
                        <th scope="col">Total</th>
                        <th scope="col">Support(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $kandidat1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $K1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr class="<?php echo e($K1['support_persen'] < $min_support ? 'table-danger' : ''); ?>">
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($K1['nama_item']); ?></td>
                            <td><?php echo e($K1['jumlah']); ?></td>
                            <td><?php echo e($K1['support_persen']); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if(count($kandidat1) >= 10 && count($kandidat1) != $stopLoadKandidat1): ?>
                <button wire:click.prevent="loadKandidat1" class="btn btn-primary btn-sm btn-block mb-10">Tampilkan
                    Lebih
                    Banyak
                </button>
            <?php endif; ?>

            
            <?php if(empty($large1)): ?>
                <div class="alert alert-warning" role="alert">
                    Proses Berhenti dikarenakan tidak ada data yang melebihi minimum support <b><?php echo e($min_support); ?>%</b>
                    yang telah ditetapkan
                </div>
            <?php else: ?>
                <div class="clearfix mb-20 mt-5">
                    <div class="pull-left">
                        <h4 class="text-blue h4">L1 (Large 1-itemset)</h4>
                        <p class="mb-5"><small>Pola Frekuensi Tinggi (1-itemset)</small></p>
                    </div>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">No </th>
                            <th scope="col">Item</th>
                            <th scope="col">Total</th>
                            <th scope="col">Support(%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $large1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $L1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($L1['nama_item']); ?></td>
                                <td><?php echo e($L1['jumlah']); ?></td>
                                <td><?php echo e($L1['support_persen']); ?>%</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($large1) >= 10 && count($large1) != $stopLoadLarge1): ?>
                    <button wire:click.prevent="loadLarge1" class="btn btn-primary btn-sm btn-block">Tampilkan Lebih
                        Banyak
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <!-- Bordered table End -->
    </div>
    

    
    <?php if(count($kandidat2) > 0): ?>
        <div class="min-height-200px">
            <!-- Bordered table  start -->
            <div class="pd-20 card-box mb-30">
                <div class="clearfix mb-20">
                    <div class="pull-left">
                        <h4 class="text-blue h4">C2 (Kandidat 2-itemset)</h4>
                        <small>
                            <p>Jika terdapat tabel berwarna <code>Merah</code> maka item tersebut kurang dari batasan
                                minimum
                                support <strong><?php echo e($min_support); ?>%</strong>
                            </p>
                        </small>
                    </div>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">No </th>
                            <th scope="col">Items</th>
                            <th scope="col">Total</th>
                            <th scope="col">Support(%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $kandidat2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $K2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr class="<?php echo e($K2['support_persen'] < $min_support ? 'table-danger' : ''); ?>">
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($K2['nama_item']); ?></td>
                                <td><?php echo e($K2['jumlah']); ?></td>
                                <td><?php echo e($K2['support_persen']); ?>%</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($kandidat2) >= 10 && count($kandidat2) != $stopLoadKandidat2): ?>
                    <button wire:click.prevent="loadKandidat2" class="btn btn-primary btn-sm btn-block mb-10">Tampilkan
                        Lebih
                        Banyak
                    </button>
                <?php endif; ?>

                
            <?php if(empty($large2)): ?>
                <div class="alert alert-warning" role="alert">
                    Proses Berhenti dikarenakan tidak ada data yang melebihi minimum support
                    <b><?php echo e($min_support); ?>%</b>
                    yang telah ditetapkan
                </div>
            <?php else: ?>
                <div class="clearfix mb-20 mt-5">
                    <div class="pull-left">
                        <h4 class="text-blue h4">L2 (Large 2-itemset)</h4>
                        <p class="mb-5"><small>Pola Frekuensi Tinggi (2-itemset)</small></p>
                    </div>
                </div>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">No </th>
                            <th scope="col">Items</th>
                            <th scope="col">Total</th>
                            <th scope="col">Support(%)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 0; ?>
                        <?php $__currentLoopData = $large2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $L2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $i++; ?>
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($L2['nama_item']); ?></td>
                                <td><?php echo e($L2['jumlah']); ?></td>
                                <td><?php echo e($L2['support_persen']); ?>%</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php if(count($large2) >= 10 && count($large2) != $stopLoadLarge2): ?>
                    <button wire:click.prevent="loadLarge2" class="btn btn-primary btn-sm btn-block">Tampilkan Lebih
                        Banyak
                    </button>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <!-- Bordered table End -->
    </div>
<?php endif; ?>



<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('aturan-asosiasi.rule-dua-item', [])->html();
} elseif ($_instance->childHasBeenRendered('l349349248-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l349349248-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l349349248-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l349349248-0');
} else {
    $response = \Livewire\Livewire::mount('aturan-asosiasi.rule-dua-item', []);
    $html = $response->html();
    $_instance->logRenderedChild('l349349248-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>



<?php if(count($kandidat3) && count($large1) && count($large2) > 0): ?>
    <div class="min-height-200px">
        <div class="pd-20 card-box mb-30">
            <div class="clearfix mb-20">
                <div class="pull-left">
                    <h4 class="text-blue h4">C3 (Kandidat 3-itemset)</h4>
                    <small>
                        <p>Jika terdapat tabel berwarna <code>Merah</code> maka item tersebut kurang dari batasan
                            minimum
                            support <strong><?php echo e($min_support); ?>%</strong>
                        </p>
                    </small>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No </th>
                        <th scope="col">Items</th>
                        <th scope="col">Total</th>
                        <th scope="col">Support(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $kandidat3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $K3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr class="<?php echo e($K3['support_persen'] < $min_support ? 'table-danger' : ''); ?>">
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($K3['nama_item']); ?></td>
                            <td><?php echo e($K3['jumlah']); ?></td>
                            <td><?php echo e($K3['support_persen']); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if(count($kandidat3) >= 10 && count($kandidat3) != $stopLoadKandidat3): ?>
                <button wire:click.prevent="loadKandidat3"
                    class="btn btn-primary btn-sm btn-block mb-10">Tampilkan
                    Lebih
                    Banyak
                </button>
            <?php endif; ?>

        <?php if(empty($large3)): ?>
            <div class="alert alert-warning" role="alert">
                Proses Berhenti dikarenakan tidak ada data yang melebihi minimum support
                <b><?php echo e($min_support); ?>%</b>
                yang telah ditetapkan
            </div>
        <?php else: ?>
            <div class="clearfix mb-20 mt-5">
                <div class="pull-left">
                    <h4 class="text-blue h4">L3 (Large 3-itemset)</h4>
                    <p class="mb-5"><small>Pola Frekuensi Tinggi (3-itemset)</small></p>
                </div>
            </div>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">No </th>
                        <th scope="col">Items</th>
                        <th scope="col">Total</th>
                        <th scope="col">Support(%)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0; ?>
                    <?php $__currentLoopData = $large3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $L3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $i++; ?>
                        <tr>
                            <td><?php echo e($i); ?></td>
                            <td><?php echo e($L3['nama_item']); ?></td>
                            <td><?php echo e($L3['jumlah']); ?></td>
                            <td><?php echo e($L3['support_persen']); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php if(count($large3) >= 10 && count($large3) != $stopLoadLarge3): ?>
                <button wire:click.prevent="loadLarge3" class="btn btn-primary btn-sm btn-block">Tampilkan Lebih
                    Banyak
                </button>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>



<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('aturan-asosiasi.rule-tiga-item', [])->html();
} elseif ($_instance->childHasBeenRendered('l349349248-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l349349248-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l349349248-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l349349248-1');
} else {
    $response = \Livewire\Livewire::mount('aturan-asosiasi.rule-tiga-item', []);
    $html = $response->html();
    $_instance->logRenderedChild('l349349248-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


</div>
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/livewire/aturan-asosiasi/hitung-pola-tata-letak.blade.php ENDPATH**/ ?>