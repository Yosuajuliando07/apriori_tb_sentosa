<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>