<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- Basic Page Info -->
    <meta charset="utf-8">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Site favicon -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/vendors/images/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/vendors/images/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/vendors/images/favicon-16x16.png')); ?>">

    <!-- Mobile Specific Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet">
    <!-- CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendors/styles/core.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendors/styles/icon-font.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendors/styles/style.css')); ?>">
    <?php echo $__env->yieldPushContent('css'); ?>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-119386393-1"></script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag('js', new Date());

        gtag('config', 'UA-119386393-1');

    </script>
</head>

<body class="login-page">
    <div class="login-header box-shadow">
        <div class="container-fluid d-flex justify-content-between align-items-center">
            <div class="brand-logo">
                <a href="<?php echo e(route('login')); ?>">
                    <img src="<?php echo e(asset('assets/vendors/images/logo-biru.png')); ?>" alt="">
                </a>
            </div>

            <?php if(Request::is('password/reset*')): ?>
            <div class="login-menu">
                <ul>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                </ul>
            </div>
            <?php endif; ?>


        </div>
    </div>
    <div class="login-wrap d-flex align-items-center flex-wrap justify-content-center">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <!-- js -->
    <script src="<?php echo e(asset('assets/vendors/scripts/core.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/scripts/script.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/scripts/process.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/scripts/layout-settings.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('js'); ?>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/layouts/app_auth.blade.php ENDPATH**/ ?>