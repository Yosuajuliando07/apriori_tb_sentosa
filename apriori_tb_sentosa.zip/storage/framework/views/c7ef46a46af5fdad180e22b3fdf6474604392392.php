<div class="left-side-bar">
    <div class="brand-logo">
        <a href="<?php echo e(route('dashboard')); ?>">
            
            <img src="<?php echo e(asset('assets/vendors/images/logo-putih.png')); ?>" alt="" class="light-logo">
        </a>
        <div class="close-sidebar" data-toggle="left-sidebar-close">
            <i class="ion-close-round"></i>
        </div>
    </div>
    <div class="menu-block customscroll">
        <div class="sidebar-menu">
            <ul id="accordion-menu">

                <li>
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="dropdown-toggle no-arrow <?php echo e(Request::is('dashboard') ? 'active' : ''); ?>">
                        <span class="micon dw dw-house-1 "></span><span class="mtext">Dashboard</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('transaksi.index')); ?>"
                        class="dropdown-toggle no-arrow <?php echo e(Request::is('transaksi*') ? 'active' : ''); ?>">
                        <span class="micon dw dw-analytics-19"></span><span class="mtext">Kelola Data Transaksi</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('tata-letak-barang.create')); ?>"
                        class="dropdown-toggle no-arrow <?php echo e(Request::is(['tata-letak-barang*', 'pola-penjualan-produk-hasil-perhitungan']) ? 'active' : ''); ?>">
                        <span class="micon dw dw-table"></span><span class="mtext">Tata Letak Barang</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('pengaturan.akun')); ?>"
                        class="dropdown-toggle no-arrow <?php echo e(Request::is(['pengaturan-akun*', 'edit-profil*']) ? 'active' : ''); ?>">
                        <span class="micon dw dw-settings"></span><span class="mtext">Pengaturan Akun</span>

                        

                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-toggle no-arrow"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <span class="micon dw dw-logout"></span><span class="mtext">Keluar</span>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/layouts/komponen/sidebar.blade.php ENDPATH**/ ?>