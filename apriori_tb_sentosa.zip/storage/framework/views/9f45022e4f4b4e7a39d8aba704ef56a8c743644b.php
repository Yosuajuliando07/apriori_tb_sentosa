<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pd-ltr-20">
        <div class="row">
            <div class="col-xl-6 mb-30">
                <div class="card-box height-100-p widget-style1">
                    <div class="d-flex flex-wrap align-items-center">
                        <div class="progress-data">
                            <div id="chart"></div>
                        </div>
                        <div class="widget-data">
                            <div class="h4 mb-0">TOTAL</div>
                            <div class="weight-600 font-14">Transaksi</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 mb-30">
                <div class="card-box height-100-p widget-style1">
                    <div class="d-flex flex-wrap align-items-center">
                        <div class="progress-data">
                            <div id="chart2"></div>
                        </div>
                        <div class="widget-data">
                            <div class="h4 mb-0">TOTAL</div>
                            <div class="weight-600 font-14">Barang</div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row">
            <div class="col-xl-12 mb-30">
                <div class="card-box height-100-p pd-20">

                    <div class="clearfix mb-20">
                        <div class="pull-left">
                            <h4 class="text-blue h4">10 Penjualan Terlaris</h4>
                        </div>
                        <div class="pull-right">
                            <small class=""><?php echo e($tglAwal); ?> - <?php echo e($tglAkhir); ?></small>
                        </div>
                    </div>
                    <div id="dril-data-transaksi"></div>
                    <div id="pie-data-transaksi"></div>
                </div>
            </div>
            
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    
    
    <script src="<?php echo e(asset('js/highcharts/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/highcharts/highcharts-3d.js')); ?>"></script>
    

    

    <script>
        Highcharts.chart('pie-data-transaksi', {
            chart: {
                type: 'pie',
                options3d: {
                    enabled: true,
                    alpha: 45
                }
            },
            credits: {
                enabled: false
            },
            title: false,
            plotOptions: {
                pie: {
                    innerSize: 100,
                    depth: 45
                }
            },
            series: [{
                name: 'Total',
                data: <?php echo json_encode($chart_terlaris); ?>

            }]
        });
    </script>
    <script>
        Highcharts.chart('dril-data-transaksi', {
            chart: {
                type: 'column',
                // options3d: {
                // enabled: true,
                // alpha: 15,
                // beta: 15,
                // depth: 50,
                // viewDistance: 25
                // }
            },
            credits: {
                enabled: false
            },

            title: false,

            yAxis: {
                title: false
            },
            legend: {
                enabled: false
            },

            xAxis: {
                type: 'category'
            },

            plotOptions: {
                series: {
                    depth: 25,
                    alpha: 15,
                    beta: 15,
                    colorByPoint: true
                }
            },

            series: [{
                type: 'column',
                name: 'Total',
                data: <?php echo json_encode($chart_terlaris); ?>

            }]
        });
    </script>

    <script src="<?php echo e(asset('assets/src/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
    
    
    <script>
        var options = {
            series: [<?php echo json_encode($transaksiCount); ?>],
            grid: {
                padding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
            },
            chart: {
                height: 100,
                width: 70,
                type: 'radialBar',
            },
            plotOptions: {
                radialBar: {
                    hollow: {
                        size: '50%',
                    },
                    dataLabels: {
                        name: {
                            show: false,
                            color: '#fff'
                        },
                        value: {
                            show: true,
                            color: '#333',
                            offsetY: 5,
                            fontSize: '15px',
                            // ----------------
                            formatter: function(val) {
                                return parseInt(val);
                            },
                        }
                    }
                }
            },
            colors: ['#ecf0f4'],
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: 'diagonal1',
                    shadeIntensity: 0.8,
                    gradientToColors: ['#1b00ff'],
                    inverseColors: false,
                    opacityFrom: [1, 0.2],
                    opacityTo: 1,
                    stops: [0, 100],
                }
            },
            states: {
                normal: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
                hover: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
                active: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
            }
        };


        var options2 = {
            series: [<?php echo json_encode($barangCount); ?>],
            grid: {
                padding: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
            },
            chart: {
                height: 100,
                width: 70,
                type: 'radialBar',
            },
            plotOptions: {
                radialBar: {
                    hollow: {
                        size: '50%',
                    },
                    dataLabels: {
                        name: {
                            show: false,
                            color: '#fff'
                        },
                        value: {
                            show: true,
                            color: '#333',
                            offsetY: 5,
                            fontSize: '15px',
                            // ----------------
                            formatter: function(val) {
                                return parseInt(val);
                            },
                        }
                    }
                }
            },
            colors: ['#ecf0f4'],
            fill: {
                type: 'gradient',
                gradient: {
                    shade: 'dark',
                    type: 'diagonal1',
                    shadeIntensity: 1,
                    gradientToColors: ['#009688'],
                    inverseColors: false,
                    opacityFrom: [1, 0.2],
                    opacityTo: 1,
                    stops: [0, 100],
                }
            },
            states: {
                normal: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
                hover: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
                active: {
                    filter: {
                        type: 'none',
                        value: 0,
                    }
                },
            }
        };

        var chart = new ApexCharts(document.querySelector("#chart"), options);
        chart.render();

        var chart2 = new ApexCharts(document.querySelector("#chart2"), options2);
        chart2.render();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/dashboard.blade.php ENDPATH**/ ?>