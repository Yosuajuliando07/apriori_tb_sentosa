<!DOCTYPE html>
<html>

<head>
    <title>Aturan Asosiasi 2 item</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 11pt;
        }
    </style>
    <center>
        <h4><?php echo e(env('APP_NAME')); ?></h4>
        <h5><a target="_blank" href="<?php echo e(env('APP_URL')); ?>">Sistem Pengaturan Tata Letak Barang</a></h5>
        <h5>Toko Bangunan Sentosa</h5>
    </center>


    <div class="row ml-1 mt-5">
        <table>
            <tbody>
                <tr>
                    <td>Tanggal Transaksi</td>
                    <td>&nbsp;&nbsp;:&nbsp;</td>
                    <td><?php echo e($tglAwal); ?> - <?php echo e($tglAkhir); ?></td>
                </tr>
                <tr>
                    <td>Minimum Support</td>
                    <td>&nbsp;&nbsp;:&nbsp;</td>
                    <td><?php echo e($find->min_support); ?>&#37;</td>
                </tr>
                <tr>
                    <td>Minimum Confidence</td>
                    <td>&nbsp;&nbsp;:&nbsp;</td>
                    <td><?php echo e($find->min_confidence); ?>&#37;</td>
                </tr>
            </tbody>
        </table>
    </div>


    <table class='table table-bordered mt-3'>
        <thead>
            <tr class="table-active">
                <th scope="col">No </th>
                <th scope="col">Rule 2-itemset</th>
                <th scope="col">Support(&#37;)</th>
                <th scope="col">Confidence(&#37;)</th>
                <th scope="col">Lift Ratio</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1 ?>
            <?php $__currentLoopData = $aturanAsosiasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AS2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($AS2->rule); ?></td>
                    <td><?php echo e($AS2->support_persen); ?>&#37;</td>
                    <td><?php echo e($AS2->confidence_persen); ?>&#37;</td>
                    <td><?php echo e(ucwords($AS2->lift_ratio_text)); ?> </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/tata_letak_barang/cetak_2_item.blade.php ENDPATH**/ ?>