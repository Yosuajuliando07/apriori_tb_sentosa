 

 <?php if(count($aturanAsosiasiFinal3Items) > 0): ?>
     <div class="min-height-200px">
         <div class="pd-20 card-box mb-30">
             <div class="clearfix mb-20">
                 <div class="pull-left">
                     <h4 class="text-blue h4">ATURAN ASOSIASI (Rule 3-itemset)</h4>
                     <p class="mb-5">
                         <small>Aturan Asosiasi (Rule) yang memenuhi batasan Minimum Confidence
                             <strong><?php echo e($min_confidence); ?>%</strong>
                         </small>
                     </p>
                 </div>
                 <div class="pull-right">
                     <div class="dropdown show">
                         <a class="btn btn-primary btn-sm dropdown-toggle" href="#" role="button"
                             data-toggle="dropdown" aria-expanded="true">
                             Aksi Lainnya
                         </a>
                         <div class="dropdown-menu dropdown-menu-right " x-placement="bottom-end"
                             style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(108px, 40px, 0px);">
                             <?php if($sortByConsequentRule3 == false): ?>
                                 <a class="dropdown-item" target="_blank" href="<?php echo e(route('cetak.3.item')); ?>">Cetak
                                     Laporan (PDF)</a>
                                 <button class="dropdown-item" wire:click.prevent="showbyConsequentRule3">Sort by
                                     Consequent</button>
                             <?php else: ?>
                                 <button class="dropdown-item" wire:click.prevent="showSortByDefaultRule3">Sort by
                                     Default</button>
                             <?php endif; ?>
                         </div>
                     </div>
                 </div>
             </div>




             <?php if($sortByConsequentRule3 == true): ?>
                 <table class="table table-bordered ">
                     <thead>
                         <tr>
                             <th scope="col">No</th>
                             <th scope="col" class="w-25">Consequent</th>
                             <th scope="col">Antecedent</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php $i = 0; ?>
                         <?php $__currentLoopData = $filterByConsequentRule3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php $i++; ?>
                             <tr>
                                 <td><?php echo e($i); ?></td>
                                 <td><?php echo e($key); ?></td>
                                 <td><?php echo e(implode(', ', $data)); ?></td>
                             </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                 </table>
                 <?php if(count($filterByConsequentRule3) >= 10 && count($filterByConsequentRule3) != $stopLoadfilterByConsequentRule3): ?>
                     <button wire:click.prevent="loadfilterByConsequentRule3"
                         class="btn btn-primary btn-sm btn-block">Tampilkan
                         Lebih
                         Banyak
                     </button>
                 <?php endif; ?>
             <?php else: ?>
                 <table class="table table-bordered">
                     <thead>
                         <tr>
                             <th scope="col">No </th>
                             <th scope="col">Rule</th>
                             <th scope="col">Support(%)</th>
                             <th scope="col">Confidence(%)</th>
                             <th scope="col">Lift Ratio</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php $i = 0; ?>
                         <?php $__currentLoopData = $aturanAsosiasiFinal3Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AS3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php $i++; ?>
                             <tr class="<?php echo e($AS3['confidence_persen'] < $min_confidence ? 'table-danger' : ''); ?>">
                                 <td><?php echo e($i); ?></td>
                                 <td><?php echo e($AS3['rule']); ?></td>
                                 <td><?php echo e($AS3['support_persen']); ?>%</td>
                                 <td><?php echo e($AS3['confidence_persen']); ?>%</td>
                                 <td><?php echo e(ucwords($AS3['lift_ratio_text'])); ?> </td>
                             </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                 </table>
                 <?php if(count($aturanAsosiasiFinal3Items) >= 10 && count($aturanAsosiasiFinal3Items) != $stopLoadRule3): ?>
                     <button wire:click.prevent="loadRule3" class="btn btn-primary btn-sm btn-block">Tampilkan
                         Lebih
                         Banyak
                     </button>
                 <?php endif; ?>
             <?php endif; ?>
         </div>
     </div>
 <?php else: ?>
     
     <div></div>
 <?php endif; ?>
 
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/livewire/aturan-asosiasi/rule-tiga-item.blade.php ENDPATH**/ ?>