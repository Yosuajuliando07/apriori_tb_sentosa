<div class="header">
    <div class="header-left">
        <div class="menu-icon dw dw-menu"></div>
    </div>
    <div class="header-right">
        

        <div class="user-info-dropdown">
            <div class="dropdown">
                <a class="dropdown-toggle no-arrow" href="#" role="button" data-toggle="dropdown">
                    <span class="user-icon">
                        <img src="<?php echo e(asset('/storage/akun/' . Auth::user()->gambar)); ?>"
                            alt="<?php echo e(Auth::user()->nama); ?>">
                    </span>
                    <span class="user-name"><?php echo e(Auth::user()->nama); ?></span>
                </a>
                
            </div>
        </div>


    </div>
</div>
<?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/layouts/komponen/header.blade.php ENDPATH**/ ?>