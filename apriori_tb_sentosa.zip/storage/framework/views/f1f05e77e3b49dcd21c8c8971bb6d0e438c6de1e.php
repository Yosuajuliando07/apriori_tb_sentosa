<?php $__env->startSection('title', 'Tata Letak Barang'); ?>

<?php $__env->startPush('css'); ?>
    <!-- cdn datetimepicker css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/datetimepicker/jquery.datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pd-ltr-20 xs-pd-20-10">
        <div class="card-box pd-20 height-100-p mb-30">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <img src="<?php echo e(asset('assets/vendors/images/rak.png')); ?>" alt="">
                </div>
                <div class="col-md-8">
                    <h4 class="font-20 weight-500 mb-10 text-capitalize">
                        Pengenalan Fitur <div class="weight-600 font-30 text-blue">Atur Tata Letak Barang!</div>
                    </h4>
                    <p class="font-18 max-width-600">Pengaturan Tata Letak Barang dilakukan dengan teknik Analisa Asosiasi
                        dari bidang ilmu data mining sehingga menghasilkan pola penjualan produk atau barang yang kemudian
                        dijadikan acuan dalam pengaturan
                        tata letak
                        barang.</p>
                </div>
            </div>
        </div>
        <div class="min-height-200px">
            <div class="row clearfix">
                <div class="col-md-12 col-sm-12 mb-30">
                    <div class="pd-20 card-box height-100-p">
                        <h4 class="mb-15 text-blue h4">Hitung Pola Tata Letak</h4>
                        <div class="alert alert-warning" role="alert">
                            <b>Minimum support</b> dan <b>minimum confidence</b> adalah nilai batas <em>(threshold)</em>
                            yang
                            nantinya
                            digunakan
                            untuk menentukan aturan asosiasi yang terbaik.

                            
                        </div>
                        <form action="<?php echo e(route('tata-letak-barang.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="tanggal_awal">Tanggal Awal</label>
                                        <input name="tanggal_awal" id="tanggal_awal" class="form-control date-id"
                                            type="text" value="<?php echo e($tanggal_awal); ?>" required>
                                    </div>
                                </div>

                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="tanggal_akhir">Tanggal Akhir</label>
                                        <input name="tanggal_akhir" id="tanggal_akhir" class="form-control date-id"
                                            type="text" value="<?php echo e($tanggal_akhir); ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="min_support">Minimum Support (%)</label>
                                        <input name="min_support" id="min_support" class="form-control" type="number"
                                            min="1" max="100" required placeholder="1-100" value="25"
                                            autocomplete="off">
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <label for="min_confidence">Minimum Confidence (%)</label>
                                        <input name="min_confidence" id="min_confidence" class="form-control" type="number"
                                            min="1" max="100" required placeholder="1-100" value="25"
                                            autocomplete="off">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary btn-sm">Hitung</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/datetimepicker/jquery.datetimepicker.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datetimepicker/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datetimepicker/datetimepicker.js')); ?>"></script>

    
    
    
    
    <script src="https://unpkg.com/sweetalert2@11.4.20/dist/sweetalert2.all.js"></script>
    <script type="text/javascript">
        window.onbeforeunload = function() {
            setTimeout(function() {
                //https://sweetalert2.github.io/
                let timerInterval
                Swal.fire({
                    title: 'SEDANG MEMPROSES',
                    html: 'Rendahnya minimum support yang ditetapkan, membuat proses ini mungkin memerlukan waktu yang cukup lama',
                    // timer: 100000,
                    timerProgressBar: true,
                    didOpen: () => {
                        Swal.showLoading()
                    },

                })
                // OpenBootstrapPopup();
            }, 10000); //10 detik

        };

        // function OpenBootstrapPopup() {
        //     $("#simpleModal").modal('show');
        // }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/tata_letak_barang/create.blade.php ENDPATH**/ ?>