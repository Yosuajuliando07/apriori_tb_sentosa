<?php $__env->startSection('title', 'Edit Data Transaksi'); ?>

<?php $__env->startPush('css'); ?>
    <!-- cdn datetimepicker css-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('js/datetimepicker/jquery.datetimepicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Select-2 Start -->
    <div class="pd-20 card-box mb-30">
        <form method="POST" action="<?php echo e(route('transaksi.update', $transaksiBarang->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="clearfix">
                <div class="pull-left">
                    <h4 class="text-blue h4">Barang</h4>
                    <p class="mb-30">Jenis bahan bangunan</p>
                </div>
                <div class="pull-right">
                    <a href="<?php echo e(route('transaksi.index')); ?>" type="button" class="btn text-primary">Kembali</a>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <select class="custom-select2 form-control" name="jenis_bahan_bangunan"
                            style="width: 100%; height: 38px;">
                            <option selected disabled><?php echo e(__('pilih data')); ?></option>
                            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($item->id == $transaksiBarang->barang_id): ?> selected <?php endif; ?>>
                                    <?php echo e($item->jenis_bahan_bangunan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <hr>
            <div class="clearfix">
                <div class="pull-left">
                    <h4 class="text-blue h4">Transaksi</h4>
                    <p class="mb-30">Kode Transaksi</p>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <select class="custom-select2 form-control" name="kode_transaksi"
                            style="width: 100%; height: 38px;">
                            <option selected disabled><?php echo e(__('pilih data')); ?></option>
                            <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php if($item->id == $transaksiBarang->transaksi_id): ?> selected <?php endif; ?>>
                                    <?php echo e($item->kode_transaksi); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
        </form>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('js/datetimepicker/jquery.datetimepicker.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datetimepicker/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datetimepicker/datetimepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/validation/form_input.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\apriori_tb_sentosa\resources\views/transaksi/edit.blade.php ENDPATH**/ ?>