jQuery.datetimepicker.setLocale('id')
$('.date-id').datetimepicker({
    timepicker: false,
    datetimepicker: true,
    format: 'd-m-Y',
});
